package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.cos
import kotlin.math.sin

private val Bg = Color(0xFF04070D)
private val Dim = Color(0xFF8A97AB)
private val Mono = FontFamily.Monospace

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF39D0FF), background = Bg, surface = Color(0xFF0B1220),
                    onBackground = Color.White, onSurface = Color.White, onPrimary = Bg,
                )
            ) { Root() }
        }
    }

    override fun onStart() { super.onStart(); Bus.appVisible = true }
    override fun onStop() { super.onStop(); Bus.appVisible = false }
}

private fun micOk(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

private fun notifOk(ctx: Context) = Build.VERSION.SDK_INT < 33 ||
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

private fun launch(ctx: Context, i: Intent) {
    try { ctx.startActivity(i) } catch (e: Exception) { Toast.makeText(ctx, "Açılamadı", Toast.LENGTH_SHORT).show() }
}

@Composable
fun Root() {
    var settings by remember { mutableStateOf(false) }
    BackHandler(enabled = settings) { settings = false }
    Box(Modifier.fillMaxSize().background(Bg)) {
        if (settings) SettingsScreen { settings = false } else MainScreen { settings = true }
    }
}

@Composable
fun MainScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val state by Bus.state.collectAsStateWithLifecycle()
    val heard by Bus.heard.collectAsStateWithLifecycle()
    val reply by Bus.reply.collectAsStateWithLifecycle()
    val info by Bus.info.collectAsStateWithLifecycle()
    val ttsMissing by Bus.ttsMissing.collectAsStateWithLifecycle()
    val level by Bus.level.collectAsStateWithLifecycle()
    val micOpen by Bus.mic.collectAsStateWithLifecycle()
    val cfg by Prefs.cfg.collectAsStateWithLifecycle()
    var rationale by remember { mutableStateOf(false) }
    var pendingAction by remember { mutableStateOf(A_START) }

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (micOk(ctx)) JarvisService.send(ctx, pendingAction)
        else Toast.makeText(ctx, "Mikrofon izni verilmedi", Toast.LENGTH_LONG).show()
    }

    fun begin(action: String) {
        if (micOk(ctx)) JarvisService.send(ctx, action) else { pendingAction = action; rationale = true }
    }

    val persona = Persona.of(cfg.persona)
    val pc = Color(persona.color)
    val running = state != JState.OFF
    val status = when (state) {
        JState.OFF -> "ÇEVRİMDIŞI"
        JState.WAITING -> "BEKLEMEDE — JARVIS, FRIDAY VEYA ULTRON DEYİN"
        JState.LISTENING -> "DİNLİYOR"
        JState.PROCESSING -> "DÜŞÜNÜYOR…"
        JState.SPEAKING -> "KONUŞUYOR"
        JState.SLEEPING -> if (cfg.wakeEnabled) "UYKU MODU — MİKROFON KAPALI" else "SESLE UYANDIRMA KAPALI — 🎤 KULLANIN"
        JState.PAUSED -> "EKRAN KAPALI — DURAKLATILDI"
    }

    Box(Modifier.fillMaxSize()) {
        HudBackdrop(pc)
        Column(
            Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (p in Persona.values()) {
                        PersonaChip(p, p == persona) { Prefs.update { it.copy(persona = p.key) } }
                    }
                }
                TextButton(onClick = onSettings) { Text("AYARLAR", fontFamily = Mono, fontSize = 12.sp, color = pc) }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    if (micOpen) "● MİKROFON: AÇIK" else "○ MİKROFON: KAPALI",
                    color = if (micOpen) Color(0xFFFF6B6B) else Dim, fontFamily = Mono, fontSize = 11.sp,
                )
                Text(
                    if (Build.VERSION.SDK_INT >= 33 && cfg.noise) "SES MOTORU: GELİŞMİŞ" else "SES MOTORU: NORMAL",
                    color = Dim, fontFamily = Mono, fontSize = 11.sp,
                )
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Hud(state, level, pc, Modifier.size(300.dp))
            }
            Text(persona.label, color = pc, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text(status, color = pc.copy(alpha = 0.8f), fontFamily = Mono, fontSize = 12.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            if (heard.isNotEmpty()) Text("> $heard", color = Color(0xFFB9C4D6), fontFamily = Mono, fontSize = 13.sp, textAlign = TextAlign.Center)
            if (reply.isNotEmpty()) Text(reply, color = pc, fontSize = 15.sp, textAlign = TextAlign.Center)
            if (ttsMissing) Text("⚠ Türkçe ses paketi yok. Ayarlar'dan yükleyin.", color = Color(0xFFFFB84D), fontSize = 12.sp, textAlign = TextAlign.Center)
            if (info.isNotEmpty()) Text(info, color = Dim, fontFamily = Mono, fontSize = 10.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { if (running) JarvisService.send(ctx, A_STOP) else begin(A_START) }) {
                    Text(if (running) "DURDUR" else "BAŞLAT", fontFamily = Mono)
                }
                OutlinedButton(onClick = { begin(A_MANUAL) }) { Text("🎤 KONUŞ", fontFamily = Mono) }
            }
        }
    }

    if (rationale) {
        AlertDialog(
            onDismissRequest = { rationale = false },
            title = { Text("Mikrofon izni") },
            text = {
                Text(
                    "JARVIS'in sizi duyabilmesi için mikrofonu dinlemesi gerekir. " +
                        "Dinleme açıkken ekranda ve bildirimde \"Mikrofon açık\" yazar; Android da yeşil gösterge çıkarır. " +
                        "Ses kaydedilmez ve saklanmaz. Konuşma tanımayı Android'in sistem servisi (Google) yapar; " +
                        "çevrimdışı Türkçe paket yüklüyse ses cihazdan çıkmaz."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    rationale = false
                    perms.launch(
                        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
                        else arrayOf(Manifest.permission.RECORD_AUDIO)
                    )
                }) { Text("İzin ver") }
            },
            dismissButton = { TextButton(onClick = { rationale = false }) { Text("Vazgeç") } },
        )
    }
}

@Composable
private fun PersonaChip(p: Persona, selected: Boolean, onClick: () -> Unit) {
    val c = Color(p.color)
    val shape = RoundedCornerShape(4.dp)
    Box(
        Modifier
            .border(1.dp, if (selected) c else c.copy(alpha = 0.3f), shape)
            .background(if (selected) c.copy(alpha = 0.18f) else Color.Transparent, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Text(
            p.label, color = if (selected) c else c.copy(alpha = 0.6f),
            fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 11.sp,
        )
    }
}

/** Izgara ve köşe çerçeveleri. */
@Composable
private fun HudBackdrop(color: Color) {
    Canvas(Modifier.fillMaxSize()) {
        val step = 36.dp.toPx()
        var x = 0f
        while (x < size.width) {
            drawLine(color.copy(alpha = 0.05f), Offset(x, 0f), Offset(x, size.height), 1f)
            x += step
        }
        var y = 0f
        while (y < size.height) {
            drawLine(color.copy(alpha = 0.05f), Offset(0f, y), Offset(size.width, y), 1f)
            y += step
        }
        val m = 10.dp.toPx()
        val l = 26.dp.toPx()
        val a = color.copy(alpha = 0.7f)
        val w = 3f
        drawLine(a, Offset(m, m), Offset(m + l, m), w); drawLine(a, Offset(m, m), Offset(m, m + l), w)
        drawLine(a, Offset(size.width - m, m), Offset(size.width - m - l, m), w); drawLine(a, Offset(size.width - m, m), Offset(size.width - m, m + l), w)
        drawLine(a, Offset(m, size.height - m), Offset(m + l, size.height - m), w); drawLine(a, Offset(m, size.height - m), Offset(m, size.height - m - l), w)
        drawLine(a, Offset(size.width - m, size.height - m), Offset(size.width - m - l, size.height - m), w)
        drawLine(a, Offset(size.width - m, size.height - m), Offset(size.width - m, size.height - m - l), w)
    }
}

/** Merkezdeki HUD: dönen halkalar, radar, ses dalgası halkası. */
@Composable
fun Hud(state: JState, level: Float, color: Color, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "hud")
    val p by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Restart), label = "p")
    val fast = state == JState.PROCESSING
    val off = state == JState.SLEEPING || state == JState.PAUSED || state == JState.OFF
    val col = if (off) color.copy(alpha = 0.35f) else color
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        val tau = (2 * Math.PI).toFloat()
        val lv = when (state) {
            JState.LISTENING, JState.WAITING -> level
            JState.SPEAKING -> 0.45f + 0.35f * sin(p * tau * 6f)
            JState.PROCESSING -> 0.25f
            else -> 0.05f
        }
        drawCircle(Brush.radialGradient(listOf(col.copy(alpha = 0.35f), Color.Transparent), center = c, radius = r), radius = r, center = c)
        rotate(p * 180f, c) {
            for (i in 0 until 72) {
                val a = i * tau / 72f
                val len = if (i % 6 == 0) r * 0.07f else r * 0.035f
                drawLine(
                    col.copy(alpha = 0.8f),
                    Offset(c.x + cos(a) * r * 0.96f, c.y + sin(a) * r * 0.96f),
                    Offset(c.x + cos(a) * (r * 0.96f - len), c.y + sin(a) * (r * 0.96f - len)),
                    2f,
                )
            }
        }
        rotate(-p * 360f * (if (fast) 3f else 1f), c) {
            for (k in 0 until 3) {
                drawArc(
                    col, startAngle = k * 120f + 10f, sweepAngle = 70f, useCenter = false,
                    topLeft = Offset(c.x - r * 0.82f, c.y - r * 0.82f), size = Size(r * 1.64f, r * 1.64f),
                    style = Stroke(5f, cap = StrokeCap.Round),
                )
            }
        }
        if (state == JState.LISTENING) {
            rotate(p * 720f, c) {
                drawCircle(Brush.sweepGradient(listOf(Color.Transparent, col.copy(alpha = 0.45f)), center = c), radius = r * 0.7f, center = c)
            }
        }
        for (i in 0 until 64) {
            val a = i * tau / 64f
            val amp = (0.15f + lv) * (0.55f + 0.45f * sin(a * 5f + p * tau * 4f))
            val r0 = r * 0.5f
            val r1 = r0 + r * 0.16f * amp.coerceIn(0f, 1.2f)
            drawLine(col, Offset(c.x + cos(a) * r0, c.y + sin(a) * r0), Offset(c.x + cos(a) * r1, c.y + sin(a) * r1), 3f, StrokeCap.Round)
        }
        drawCircle(col.copy(alpha = 0.7f), radius = r * 0.44f, center = c, style = Stroke(2f))
        drawCircle(
            Brush.radialGradient(listOf(Color.White.copy(alpha = 0.9f), col, Color.Transparent), center = c, radius = r * 0.32f),
            radius = r * 0.32f, center = c,
        )
    }
}

@Composable
private fun SwitchRow(title: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            if (sub != null) Text(sub, fontSize = 12.sp, color = Dim)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cfg by Prefs.cfg.collectAsStateWithLifecycle()
    val running = Bus.state.collectAsStateWithLifecycle().value != JState.OFF
    val mic = micOk(ctx)

    Column(Modifier.fillMaxSize().safeDrawingPadding().padding(20.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Geri") }
            Text("Ayarlar", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        SwitchRow("Sesle uyandırma", "Kapalıysa yalnızca 🎤 düğmesiyle konuşursunuz", cfg.wakeEnabled) { v -> Prefs.update { it.copy(wakeEnabled = v) } }
        Text("Uyandırma kelimesi", fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !cfg.heyOnly, onClick = { Prefs.update { it.copy(heyOnly = false) } }, label = { Text("Doğrudan ad") })
            FilterChip(selected = cfg.heyOnly, onClick = { Prefs.update { it.copy(heyOnly = true) } }, label = { Text("Hey + ad") })
        }
        Text("Adlar: JARVIS, FRIDAY, ULTRON. Hangisini çağırırsanız o cevap verir.", fontSize = 12.sp, color = Dim)
        SwitchRow(
            "Gürültü engelleme ve kayıpsız dinleme (deneysel)",
            "Android 13+: mikrofon sesini gürültü engelleme, yankı giderme ve kazanç ile işler, tanıyıcı yeniden başlarken kelime kaçmasını önler. Tanıma kötüleşirse kapatın.",
            cfg.noise,
        ) { v -> Prefs.update { it.copy(noise = v) } }
        SwitchRow(
            "Ekran kapalıyken dinleme",
            "Garanti değildir. Redmi/HyperOS pil kısıtlaması servisi durdurabilir; aşağıdaki pil ayarını \"Kısıtlama yok\" yapın.",
            cfg.screenOff,
        ) { v -> Prefs.update { it.copy(screenOff = v) } }
        SwitchRow("Sesli yanıtlar", null, cfg.voice) { v -> Prefs.update { it.copy(voice = v) } }
        Text("Konuşma hızı", fontSize = 14.sp)
        Slider(value = cfg.rate, onValueChange = { v -> Prefs.update { it.copy(rate = v) } }, valueRange = 0.6f..1.5f)
        SwitchRow("Sürekli konuşma modu", "Komuttan sonra uyandırma kelimesi beklemeden dinlemeye devam eder", cfg.continuous) { v -> Prefs.update { it.copy(continuous = v) } }
        OutlinedTextField(
            value = cfg.city, onValueChange = { v -> Prefs.update { it.copy(city = v) } },
            label = { Text("Hava durumu şehri") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        )

        Spacer(Modifier.height(16.dp))
        Text("Yapay zekâ", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        SwitchRow(
            "Ücretsiz yapay zekâ (anahtarsız)",
            "Komutlara uymayan sorular üçüncü taraf ücretsiz bir servise (Pollinations) metin olarak gider. ChatGPT değildir, kararsız olabilir.",
            cfg.freeAi,
        ) { v -> Prefs.update { it.copy(freeAi = v) } }
        Text("ChatGPT (isteğe bağlı)", fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
        OutlinedTextField(
            value = cfg.apiKey, onValueChange = { v -> Prefs.update { it.copy(apiKey = v.trim()) } },
            label = { Text("OpenAI API anahtarı") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
        )
        OutlinedTextField(
            value = cfg.model, onValueChange = { v -> Prefs.update { it.copy(model = v.trim()) } },
            label = { Text("Model") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        )
        Text(
            if (cfg.apiKey.isBlank()) "Anahtar yok: ChatGPT kapalı, yukarıdaki ücretsiz servis kullanılır. Daha sağlam cevap için platform.openai.com'dan API anahtarı alabilirsiniz (ChatGPT Plus'tan ayrı, kullanıma göre ücretli)."
            else "ChatGPT açık. JARVIS, FRIDAY ve ULTRON kendi kişiliğiyle cevap verir ve gerekirse fener, alarm, hava gibi eylemleri kendisi seçer. Anahtar yalnızca bu telefonda saklanır; ChatGPT'ye sadece konuştuğunuzun yazıya dökülmüş metni gider, ses gitmez.",
            fontSize = 12.sp, color = Dim,
        )

        Spacer(Modifier.height(16.dp))
        Text("Durum", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("Mikrofon izni: " + if (mic) "verildi" else "verilmedi", color = if (mic) Color(0xFF4DFFB4) else Color(0xFFFFB84D))
        Text("Bildirim izni: " + if (notifOk(ctx)) "verildi" else "verilmedi")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                launch(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            }) { Text("Uygulama ayarları") }
            OutlinedButton(onClick = { launch(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Pil ayarı") }
        }
        OutlinedButton(onClick = {
            launch(ctx, Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
        }) { Text("Türkçe ses paketi yükle") }

        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            if (mic) JarvisService.send(ctx, A_TEST)
            else Toast.makeText(ctx, "Önce ana ekrandan Başlat'a basıp mikrofon izni verin", Toast.LENGTH_LONG).show()
        }, modifier = Modifier.fillMaxWidth()) { Text(if (running) "Asistanı test et" else "Asistanı başlat ve test et") }

        Spacer(Modifier.height(16.dp))
        Text(
            "Gizlilik: Ses kaydedilmez veya saklanmaz. Mikrofon yalnızca dinleme açıkken kullanılır ve ekranda/bildirimde gösterilir. " +
                "Konuşma tanıma Android'in sistem servisi (Google) tarafından yapılır; çevrimdışı Türkçe paket yüklüyse ses cihazda işlenir. " +
                "İnternete hava durumu için şehir adı, yapay zekâ açıksa soruların metni gönderilir.",
            fontSize = 12.sp, color = Dim,
        )
    }
}
