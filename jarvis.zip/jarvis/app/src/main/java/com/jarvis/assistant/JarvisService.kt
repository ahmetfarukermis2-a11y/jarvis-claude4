package com.jarvis.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Mikrofon türünde ön plan servisi: uyandırma kelimesini döngüyle dinler,
 * komutu işler, Türkçe sesli yanıt verir.
 */
class JarvisService : Service() {

    companion object {
        private const val MIN_CONF = 0.4f

        fun send(ctx: Context, action: String) {
            val i = Intent(ctx, JarvisService::class.java).setAction(action)
            if (Bus.state.value == JState.OFF) {
                if (action != A_STOP) ContextCompat.startForegroundService(ctx, i)
            } else ctx.startService(i)
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var cmds: Commands

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pending = HashMap<String, () -> Unit>()

    private var rec: SpeechRecognizer? = null
    private var live = false
    private var commandMode = false
    private var onDevice = false
    private var forceCloud = false

    private var sleeping = false
    private var screenPaused = false
    private var chat = false
    private var silent = 0
    private var lowAsked = false
    private var dead = false
    private var fg = false
    private var restart: Runnable? = null
    private var lock: PowerManager.WakeLock? = null
    private var lastKey: Triple<Boolean, Boolean, Boolean>? = null
    private var cap: Capture? = null
    private var capFailed = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Notif.channels(this)
        cmds = Commands(this)
        initTts()
        ContextCompat.registerReceiver(
            this, screenRx,
            IntentFilter().apply { addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF) },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        lastKey = Triple(Prefs.cfg.value.wakeEnabled, Prefs.cfg.value.screenOff, Prefs.cfg.value.noise)
        scope.launch { Prefs.cfg.drop(1).collect { onCfg() } }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!fg && !enterForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent?.action) {
            A_STOP -> stopSelf()
            A_SLEEP -> goSleep()
            A_MANUAL -> if (!screenPaused) { silent = 0; listen(true) }
            A_TEST -> say("Test başarılı efendim. Sizi dinliyorum.") { silent = 0; listen(true) }
            else -> { sleeping = false; goIdle() }
        }
        return START_NOT_STICKY
    }

    private fun enterForeground(): Boolean {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Bus.info.value = "Mikrofon izni verilmedi."
            return false
        }
        return try {
            val n = Notif.status(this, JState.WAITING)
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
            fg = true
            true
        } catch (e: Exception) {
            Bus.info.value = "Arka plan servisi başlatılamadı: " + e.message
            false
        }
    }

    // ---------- Durum ----------

    private fun setState(s: JState) {
        if (Bus.state.value == s) return
        Bus.state.value = s
        if (s == JState.SLEEPING || s == JState.PAUSED) releaseCap()
        Bus.mic.value = cap != null || s == JState.WAITING || s == JState.LISTENING
        try {
            getSystemService(android.app.NotificationManager::class.java).notify(1, Notif.status(this, s))
        } catch (_: Exception) {
        }
    }

    private fun goIdle() {
        chat = false; silent = 0; lowAsked = false
        stopRec(); cancelRestart()
        val c = Prefs.cfg.value
        when {
            sleeping || !c.wakeEnabled -> setState(JState.SLEEPING)
            screenPaused -> setState(JState.PAUSED)
            else -> listen(false)
        }
        updateLock()
    }

    private fun goSleep() {
        sleeping = true; chat = false
        stopRec(); cancelRestart()
        updateLock()
        setState(JState.SLEEPING)
    }

    private fun after() {
        if (chat || (Prefs.cfg.value.continuous && !sleeping)) { silent = 0; listen(true) } else goIdle()
    }

    private fun onCfg() {
        val c = Prefs.cfg.value
        val key = Triple(c.wakeEnabled, c.screenOff, c.noise)
        if (key == lastKey) return
        if (key.third != lastKey?.third) { capFailed = false; releaseCap() }
        lastKey = key
        if (c.screenOff) screenPaused = false
        else if (!(getSystemService(PowerManager::class.java)).isInteractive) screenPaused = true
        val s = Bus.state.value
        if (s == JState.WAITING || s == JState.SLEEPING || s == JState.PAUSED) goIdle() else updateLock()
    }

    private fun updateLock() {
        val want = Prefs.cfg.value.screenOff && !sleeping
        if (want && lock == null) {
            lock = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:listen")
                .apply { setReferenceCounted(false); acquire() }
        } else if (!want) {
            lock?.let { if (it.isHeld) it.release() }
            lock = null
        }
    }

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF) {
                if (Prefs.cfg.value.screenOff) return
                screenPaused = true
                if (!sleeping && Bus.state.value in listOf(JState.WAITING, JState.LISTENING)) {
                    stopRec(); cancelRestart(); setState(JState.PAUSED)
                }
            } else if (i.action == Intent.ACTION_SCREEN_ON && screenPaused) {
                screenPaused = false
                if (!sleeping && Bus.state.value == JState.PAUSED) goIdle()
            }
        }
    }

    // ---------- Konuşma tanıma ----------

    @SuppressLint("NewApi")
    private fun newRecognizer(): SpeechRecognizer? {
        onDevice = Build.VERSION.SDK_INT >= 33 && !forceCloud && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
        val r = when {
            onDevice -> {
                Bus.info.value = "Tanıma: cihaz üzerinde"
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            }
            SpeechRecognizer.isRecognitionAvailable(this) -> {
                Bus.info.value = "Tanıma: sistem/Google servisi (çevrimdışı Türkçe paket yüklüyse cihazda kalır)"
                SpeechRecognizer.createSpeechRecognizer(this)
            }
            else -> null
        }
        r?.setRecognitionListener(listener)
        return r
    }

    private fun recIntent(command: Boolean) = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        if (onDevice) putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, if (command) 1500L else 1000L)
    }

    private fun listen(command: Boolean) {
        cancelRestart()
        if (screenPaused) { setState(JState.PAUSED); return }
        commandMode = command
        setState(if (command) JState.LISTENING else JState.WAITING)
        val r = rec ?: newRecognizer().also { rec = it }
        if (r == null) {
            Bus.info.value = "Bu cihazda konuşma tanıma servisi yok."
            goSleep()
            return
        }
        live = true
        try {
            val ri = recIntent(command)
            attachAudio(ri)
            r.startListening(ri)
        } catch (e: Exception) {
            live = false
            again(1000, command, true)
        }
    }

    private fun stopRec() {
        live = false
        cap?.endSession()
        try { rec?.cancel() } catch (_: Exception) {}
    }

    /** Gelişmiş ses motoru açıksa (Android 13+) tanıyıcıya kendi işlenmiş sesimizi veririz. */
    @SuppressLint("NewApi")
    private fun attachAudio(i: Intent) {
        if (Build.VERSION.SDK_INT < 33 || !Prefs.cfg.value.noise || capFailed) return
        var c = cap
        if (c == null) {
            c = Capture()
            if (!c.start()) {
                capFailed = true
                Bus.info.value = "Gelişmiş ses motoru başlatılamadı, normal mikrofon kullanılıyor."
                return
            }
            cap = c
            Bus.mic.value = true
            Bus.info.value = "Ses motoru: gürültü engelleme + kayıpsız dinleme (deneysel)"
        }
        val fd = c.openSession() ?: return
        i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, fd)
        i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1)
        i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
        i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, Capture.RATE)
    }

    private fun releaseCap() {
        cap?.stop()
        cap = null
        Bus.mic.value = false
    }

    private fun destroyRec() {
        stopRec()
        try { rec?.destroy() } catch (_: Exception) {}
        rec = null
    }

    private fun cancelRestart() {
        restart?.let { main.removeCallbacks(it) }
        restart = null
    }

    private fun again(delayMs: Long, command: Boolean, recreate: Boolean = false) {
        cancelRestart()
        val r = Runnable { if (!dead) { if (recreate) destroyRec(); listen(command) } }
        restart = r
        main.postDelayed(r, delayMs)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {
            val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (live && !t.isNullOrBlank()) Bus.heard.value = t
        }
        override fun onEvent(t: Int, p: Bundle?) {}
        override fun onError(error: Int) {
            if (!live) return
            live = false
            cap?.endSession()
            cap?.clear()   // işlenen ses bir sonraki oturuma tekrar verilmesin
            onErr(error)
        }
        override fun onResults(results: Bundle?) {
            if (!live) return
            live = false
            cap?.endSession()
            cap?.clear()
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            val scores = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
            if (list.isEmpty()) onErr(7) else if (commandMode) onCommandText(list) else onWakeText(list, scores)
        }
    }

    private fun onErr(code: Int) {
        if (code != 7 && code != 6) Bus.info.value = "Tanıma hatası kodu: $code"
        when (code) {
            6, 7 -> if (commandMode) {
                if (++silent >= (if (chat) 3 else 2)) goIdle() else again(150, true)
            } else again(120, false)
            9 -> { Bus.info.value = "Mikrofon izni yok. Ayarlardan izin verin."; goSleep() }
            12, 13 -> if (onDevice) { forceCloud = true; again(300, commandMode, true) }
            else { Bus.info.value = "Türkçe konuşma tanıma bu cihazda kullanılamıyor."; goSleep() }
            1, 2, 4, 10, 11 -> { Bus.info.value = "Konuşma tanıma servisine ulaşılamıyor, tekrar deneniyor…"; again(3000, commandMode, true) }
            else -> again(800, commandMode, true)
        }
    }

    // ---------- Akış ----------

    private fun onWakeText(list: List<String>, scores: FloatArray?) {
        val heyOnly = Prefs.cfg.value.heyOnly
        for ((i, alt) in list.withIndex()) {
            val hit = Tr.wakeFind(Tr.fold(alt), heyOnly) ?: continue
            val rest = hit.second
            val conf = scores?.getOrNull(i) ?: -1f
            if (conf > 0f && conf < MIN_CONF) continue   // yanlış algılamayı ele
            silent = 0
            val who = hit.first
            if (who.key != Prefs.cfg.value.persona) Prefs.update { it.copy(persona = who.key) }
            if (rest.any { it.isLetter() } && rest.length >= 2) {
                run(alt, list.mapNotNull { a -> Tr.wake(Tr.fold(a), heyOnly) }.filter { it.length >= 2 })
            }
            else {
                Bus.heard.value = who.label
                say(who.greets.random()) { silent = 0; listen(true) }
            }
            return
        }
        Bus.heard.value = list.firstOrNull().orEmpty()
        again(120, false)
    }

    /** Tanıyıcının verdiği tüm alternatifleri dener; ilk anlaşılan komut çalışır. */
    private fun onCommandText(list: List<String>) {
        val alts = list.map { a -> val f = Tr.fold(a); Tr.wake(f, false)?.ifBlank { f } ?: f }
        run(list[0], alts)
    }

    private fun run(display: String, alts: List<String>) {
        stopRec()
        Bus.heard.value = display
        setState(JState.PROCESSING)
        scope.launch {
            var o = Out("", K.UNKNOWN)
            for (c in alts) {
                o = try { cmds.run(c, chat) } catch (e: Exception) { Out("Bir hata oluştu efendim.") }
                if (o.kind != K.UNKNOWN) break
            }
            if (o.kind == K.UNKNOWN) {
                o = cmds.think(display, Persona.of(Prefs.cfg.value.persona))
                if (o.kind != K.UNKNOWN) chat = true   // ChatGPT cevabından sonra takip sorusu için dinlemeye devam et
            }
            if (o.kind == K.UNKNOWN) o = Out("Bu komutu anlayamadım efendim.", K.UNKNOWN)
            when (o.kind) {
                K.UNKNOWN -> say(o.text) { after() }
                K.SLEEP -> say(o.text) { goSleep() }
                K.STOP -> say(o.text) { stopSelf() }
                K.CHAT -> { chat = true; say(o.text) { silent = 0; listen(true) } }
                K.ENDCHAT -> { chat = false; say(o.text) { after() } }
                K.NORMAL -> say(o.text) { after() }
            }
        }
    }

    // ---------- Sesli yanıt ----------

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            main.post {
                val t = tts ?: return@post
                if (status == TextToSpeech.SUCCESS) {
                    val r = t.setLanguage(Tr.TR)
                    ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                    Bus.ttsMissing.value = !ttsReady
                    t.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                    )
                    t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(id: String?) {}
                        override fun onDone(id: String?) { finished(id) }
                        @Deprecated("Deprecated in Java")
                        override fun onError(id: String?) { finished(id) }
                        override fun onStop(id: String?, interrupted: Boolean) { finished(id) }
                    })
                } else Bus.ttsMissing.value = true
            }
        }
    }

    private fun finished(id: String?) {
        main.post { id?.let { pending.remove(it) }?.invoke() }
    }

    /** Konuşurken mikrofonu kapatır (kendi sesini komut sanmasın), bitince [then] çalışır. */
    private fun say(text: String, then: () -> Unit) {
        stopRec()
        val p = Persona.of(Prefs.cfg.value.persona)
        val spoken = if (p == Persona.JARVIS) text else text.replace("efendim", p.address)
        Bus.reply.value = spoken
        setState(JState.SPEAKING)
        val c = Prefs.cfg.value
        val t = tts
        // konuşma bittikten sonra ön tamponu boşalt: kendi sesimiz komut sanılmasın
        val next: () -> Unit = { main.postDelayed({ if (!dead) { cap?.clear(); then() } }, 350); Unit }
        if (!c.voice || !ttsReady || t == null) {
            if (!c.voice) beep()
            next(); return
        }
        val id = UUID.randomUUID().toString()
        pending.clear()
        pending[id] = next
        t.setSpeechRate((c.rate * p.rate).coerceIn(0.4f, 2f))
        t.setPitch(p.pitch)
        if (t.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, id) != TextToSpeech.SUCCESS) {
            pending.remove(id); next()
        }
    }

    private fun beep() {
        try {
            val g = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            g.startTone(ToneGenerator.TONE_PROP_ACK, 150)
            main.postDelayed({ g.release() }, 400)
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        dead = true
        cancelRestart()
        destroyRec()
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        try { unregisterReceiver(screenRx) } catch (_: Exception) {}
        lock?.let { if (it.isHeld) it.release() }
        releaseCap()
        scope.cancel()
        Bus.state.value = JState.OFF
        super.onDestroy()
    }
}
